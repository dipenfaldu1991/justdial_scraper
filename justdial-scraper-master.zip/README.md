# justdial-scraper
A python Programm to extract data of specific business query from a city, from justdial. 
TODO:
  1. extract phone number 
  2. get langitude and latitude
